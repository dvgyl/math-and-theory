# Upload this preprint

Create one Zenodo upload of type Publication / Preprint. Upload `manuscript.pdf` and `source-and-proofs.zip`. Use `zenodo-metadata.json` as a field-copying reference. Set the publication date when you publish; no DOI has been assigned here. Use the author name Dev D. Goyal and license Apache-2.0.

The source archive includes the manuscript, exact checkers, licenses and the portable Lean package. Follow its README to reproduce the results. The main and companion theorems are formalized; the companion generating function and polynomial corollaries have conventional proofs. Novelty and later source versions have not been certified.
