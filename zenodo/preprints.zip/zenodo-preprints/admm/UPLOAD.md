# Upload this preprint

Create one Zenodo upload of type Publication / Preprint. Upload `manuscript.pdf` and `source-and-proofs.zip`. Use `zenodo-metadata.json` as a field-copying reference. Set the publication date when you publish; no DOI has been assigned here. Use the author name Dev D. Goyal and license Apache-2.0.

The archive contains the nine-page manuscript and its source, all seven Lean proof modules, three exact arithmetic checkers, input data, a portable verifier, the verification receipt, and license notices. Follow its README to reproduce the checks. The verifier uses explicit trust-zero imports and warnings as errors.

The result concerns exactly the displayed multiplier-only ADMM update at step 199/100. Formal checking covers unique global minimizers and the infinite orbit; the finite-objective extension also certifies the unique constrained optimizer. Analytic convexity, strong convexity, C2 regularity and Lipschitz-gradient properties have conventional proofs. The literature comparison is provisional and no priority claim is made. The autonomous AI disclosure and Dev D. Goyal's publication responsibility appear directly below the manuscript title.
