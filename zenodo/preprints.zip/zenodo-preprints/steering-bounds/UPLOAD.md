# Upload this preprint

Create one Zenodo upload of type Publication / Preprint. Upload `manuscript.pdf` and `source-and-proofs.zip`. Use `zenodo-metadata.json` as a field-copying reference. Use the author name Dev D. Goyal and license Apache-2.0. Set the publication date when you publish. No DOI has been assigned here.

The source archive contains the paper, all 18 Lean source modules, the analytic figure, licenses, exact dependency pins, the complete principal theorem map, verification evidence and reproduction instructions. Follow its README to rebuild the matrix proofs. Dependencies retain separate upstream licenses and must be fetched. No compiled objects or dependency caches are included.

The exact bound is a least upper bound over actual two-qubit density matrices with computed centre. It is not attained on the flat branch with centre in [2/3, 1). The threshold concerns the specified CJWR three-setting expression, not all steerability. The physical measurement and ellipsoid correspondences use cited external results. Historical priority and the correspondence with specific published conjectures remain unverified.

The manuscript places truthful fully autonomous agentic research disclosure above the abstract. Dev D. Goyal is responsible for publication. No new human proof review or expert validation is claimed. This preparation reuses the completed fresh proof replay for unchanged proof-source hashes; no compiler was run for citation packaging.
