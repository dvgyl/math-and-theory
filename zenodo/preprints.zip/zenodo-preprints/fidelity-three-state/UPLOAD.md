# Upload this preprint

Create one Zenodo upload of type Publication / Preprint. Upload `manuscript.pdf` and `source-and-proofs.zip`. Use `zenodo-metadata.json` as a field-copying reference. Use the author name Dev D. Goyal and license Apache-2.0. Set the publication date when you publish. No DOI has been assigned here.

The source archive contains the paper, both Lean proof bundles, the theorem map, the eight-endpoint audit, verification evidence, exact dependency pins, reproduction software, source attribution, and licenses. Follow its README for strict reproduction. Dependencies must be fetched separately. Compiled objects and dependency caches are excluded.

The result covers every finite dimension, three positive semidefinite complex matrices of trace one, and nonnegative probabilities summing to one. It includes singular states and zero probabilities. The matrix uses unsquared root fidelity. The three-block entropy comparison and the ensemble bound are one result family. Historical priority is not certified by the available literature comparison.

The manuscript places its fully autonomous agentic AI research disclosure above the abstract. Dev D. Goyal is responsible for publication. No expert validation or peer review is claimed.
