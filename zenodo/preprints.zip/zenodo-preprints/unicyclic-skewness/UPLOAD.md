# Upload this preprint

Create one Zenodo upload of type Publication / Preprint. Upload `manuscript.pdf` and `source-and-proofs.zip`. Use `zenodo-metadata.json` as a field-copying reference. Use the author name Dev D. Goyal and license Apache-2.0. Set the publication date when you publish. No DOI has been assigned here.

The archive contains the unchanged 15-page manuscript and LaTeX source, all 34 Lean proof modules, a source-only verifier, the exact dependency lock, the complete integer certificate, an independent exact algebra checker, citation files, the license, and portable completed-check evidence. The generated combined-source evidence has a `.lean.txt` suffix; all runnable public Lean modules are in `proof/`. Follow README.md and VERIFICATION.md to reproduce the checks. No compiled proof objects or dependency caches are included.

The formal result is the actual finite-matrix derivative interval and local branch existence. The long-time stochastic identification and limiting sharpness family are conventional proofs. The main theorem covers positive-rate rings with at least three states and unequal forward/reverse rate products. It does not cover attached trees or additional cycles. Bibliographic priority remains subject to further literature assessment.

Fully autonomous agentic research and Dev D. Goyal's publication responsibility appear prominently below the manuscript title and at the start of the upload description. No expert human validation or peer review is claimed. The package is prepared for manual publication; no upload was performed.
