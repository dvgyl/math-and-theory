# Selected preprints for manual Zenodo upload

Prepared 29 October 2026. No upload or DOI registration has been performed.

This selection prioritizes mathematical scope and completed proof coverage across the Math and Theory collection. The selection is an editorial assessment, not a certification of historical novelty or external peer review.

| Folder | Preprint | Main result |
|---|---|---|
| `higuchi-sudbery` | Unrestricted Higuchi–Sudbery entropy bound | Sharp average entropy bound over all normalized pure four-qubit states, with attainment. |
| `universal-embezzlement` | Universal embezzlement | One target-independent catalyst family gives inverse-quadratic logarithmic root infidelity for each fixed target dimension. |
| `asymmetric-tutte` | Exact asymmetric Tutte region | Necessary and sufficient parameter inequalities for every finite matroid without loops or coloops. |
| `power-rank` | Nonquasipolynomial power ranks | An exact rank-thirteen construction and infinitely many power-rank profiles at every fixed rank at least three. |
| `admm` | Multiplier-only ADMM five-cycle | An exact period-five nonconvergent orbit with multiplier step 199/100; the algorithm differs from primal over-relaxation ADMM. |
| `steering-bounds` | Exact three-setting correlation bounds | The exact fixed-centre upper envelope over all two-qubit density matrices, including nonattainment and the singular boundary. |
| `strong-gradient` | Exact last-gradient bound | The sharp constant-step gradient-descent bound on smooth strongly convex functions over real Hilbert spaces, at every finite horizon. |
| `unicyclic-skewness` | Sharp unicyclic current bound | For positive-rate finite Markov rings with nonzero affinity, the sharp interval is −1/16 ≤ C₃/C₁ ≤ 1; matrix derivatives are formalized and the long-time cumulant identification is proved conventionally. |
| `fidelity-three-state` | Three-state root-fidelity entropy bound | The weighted root-fidelity matrix bounds the Holevo quantity for all three-state ensembles in arbitrary finite dimension, including singular states and zero probabilities. |

Each folder contains a manuscript PDF, a source-and-proofs ZIP, suggested Zenodo metadata and upload instructions. The manuscript places the autonomous AI research disclosure below its title. The proof archives include the relevant licenses and reproduction instructions.

## Upload

1. Extract this bundle and open the folder for one paper.
2. Create a separate Zenodo record of type Publication / Preprint. Upload that folder's `manuscript.pdf` and `source-and-proofs.zip`.
3. Copy the title, description, creator and keywords from `zenodo-metadata.json`. The creator is Dev D. Goyal. Select the stated Apache-2.0 license and the actual publication date.
4. Preview the record and publish when ready. Zenodo can assign a DOI. Repeat for the other papers.

The metadata files are field-copying references; they are not a request to upload the collection as one record. If a paper already has a Zenodo record, use its version workflow rather than making a duplicate record. No DOI or publication date has been invented in the supplied metadata.

## Verification and scope

The existing repository proof sources are unchanged. Their recorded successful source builds and allowed-axiom reports were checked against the current files; these were not represented as new compiler runs. The power-rank, ADMM, steering, strong-gradient, unicyclic and fidelity packages have fresh source compilation and allowed-axiom checks. Exact release archives and the new first-page disclosures were reviewed separately from the mathematical proof work.

The papers state their own boundaries. In particular, ADMM analytic regularity retains a conventional proof; the power-rank generating function and polynomial corollaries retain conventional proofs. Steering concerns the specified three-setting expression, not all steerability. Strong-gradient sharpness at arbitrary scale uses written rescaling of normalized formal attainers. Formal verification does not establish novelty, and this preparation did not clear all later-literature or source-version questions. No new human expert review is claimed.

The graph-root and projection AM–GM papers remain available in the repository, alongside the other retained notes. Incomplete general order-seven circulant and rank-two orders nine through fifteen are outside this upload batch. Narrow, known or duplicate notes were not included merely to increase the number of preprints.
