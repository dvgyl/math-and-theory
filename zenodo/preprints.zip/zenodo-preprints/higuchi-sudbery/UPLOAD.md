# Upload this preprint

Create one Zenodo upload of type Publication / Preprint. Upload `manuscript.pdf` and `source-and-proofs.zip`. Use `zenodo-metadata.json` as a field-copying reference. Use the author name Dev D. Goyal and license Apache-2.0. Set the publication date when you publish. No DOI has been assigned here.

The source archive contains the manuscript, original proof sources, licenses, pinned dependency configuration, public completed source-build evidence and reproduction instructions. Follow its README to rebuild the Lean proof and audit the permitted axioms. Dependencies retain separate upstream licenses and must be fetched. No compiled objects or dependency caches are included.

The recorded proof checks are reused for unchanged source hashes; this packaging step did not run Lean again. The manuscript places the existing autonomous AI disclosure in bold immediately after the title. Historical priority and peer review are not established by this preparation.
