# Upload this preprint

Create one Zenodo upload of type Publication / Preprint. Upload `manuscript.pdf` and `source-and-proofs.zip`. Use `zenodo-metadata.json` as a field-copying reference. Use the author name Dev D. Goyal and license Apache-2.0. Set the publication date when you publish. No DOI has been assigned here.

The archive contains the unchanged 16-page manuscript and its source, all 20 Lean proof modules, a source-only verifier, the exact dependency lock, citation files, licenses, portable completed-check evidence, and the repository release manifest. Follow README.md and VERIFICATION.md to reproduce the proof. No project objects or dependency caches are included; dependencies must be fetched and retain their upstream licenses. Selected adapted code retains its MIT notice.

The actual-function upper bound and normalized actual-function attainment cover every finite horizon and closed parameter boundary. Arbitrary-scale upper bounds are formalized; sharpness for arbitrary L > 0 and R > 0 is proved by written rescaling. The cited comparisons with earlier sources are bounded and do not establish worldwide priority.

The recorded proof checks apply to unchanged mathematical source hashes. This packaging step did not invoke Lean. Fully autonomous agentic research and Dev D. Goyal's publication responsibility appear prominently below the manuscript title and at the start of the upload description. No expert validation or peer review is claimed.
